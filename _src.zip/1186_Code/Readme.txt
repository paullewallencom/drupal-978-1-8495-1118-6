=========================
Drupal 6 Panels Cookbook
=========================

Chapter 1 to 9: Use the Mindtrades site.

Server   = localhost
Username = root
Password =  
Database = test1
  
Site username = admin
Site password = testing


------------------------


Chapter 10: Use the Communiqs site.

Server   = localhost
Username = root
Password =
Database = test2

Site username = communiqs
Site password = testing 

--------------------------


