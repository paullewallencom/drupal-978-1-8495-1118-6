// $Id$

The Facebook-style Statuses module provides users with a short textual "status"
that they can use to express themselves. Users can also post on other users'
profiles. Comprehensive settings, APIs, theming, and module integration are
included.

Extensive admin documentation is available at http://drupal.org/node/421128
Thorough API/developer documentation is at http://drupal.org/node/421336
Visit the project page at http://drupal.org/project/facebook_status
Check out the issue queue at http://drupal.org/project/issues/facebook_status

IceCreamYou wrote and maintains the module, and is available for paid
customizations. Contact him at http://drupal.org/user/201425/contact