/* $Id: README.txt,v 1.1.4.5 2009/09/22 15:11:07 aaron Exp $ */

/**********************/
 Embedded Media Import
/**********************/

****PLEASE NOTE: EMIMPORT IS DEPRECATED IN DRUPAL 6 IN FAVOR OF FEEDAPI INTEGRATION********
