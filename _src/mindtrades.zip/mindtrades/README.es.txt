Esta es la traducción al español de la interfaz de Drupal 6.0

Para traducir Drupal al Español, descomprimir el contenido de este archivo
en el directorio raiz de su copia de Drupal antes de comenzar la instalación.
 
Para enviar correcciones a la traducción, 
  http://localize.drupal.org/
  
Para otros asuntos y problemas crear un "bug", "support request", etc... en
  http://drupal.org/project/es
  
Traducción realizada y mantenida por Drupal Hispano
  http://drupal.org.es