Drupal date_popup.module README.txt
==============================================================================

Javascript popup calendar and timeentry using the jquery-calendar library,

==================================================================================
Contents
==================================================================================

If jQuery UI is installed, the version of the 'datepicker' code from
that module will be used.

If jQuery UI is not installed, the 'datepicker' code from this folder
will be used.

See:

- http://docs.jquery.com/UI/Datepicker/datepicker
- http://ui.jquery.com/functional_demos/#ui.datepicker
- http://plugins.jquery.com/project/timeEntry
